<?php 

/**
 * 
 */
class Model_kategori extends CI_Model{

	public function data_tas(){
		return $this->db->get_where("tb_barang",array('kategori' =>'tas'));
	}

	public function data_buku(){
		return $this->db->get_where("tb_barang",array('kategori' =>'buku'));
	}
}