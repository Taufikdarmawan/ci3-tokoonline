<main>
            <!--=============== HOME ===============-->
            <div class="container-fluid bg-dark py-5">
                <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Shop in style</h1>
                    <p class="lead fw-normal text-white-50 mb-0">With this shop hompeage template</p>
                </div>
            </div>
            </div>

            <!--=============== CART ===============-->
            <div class="container py-5">
            <div class="row text-center row-cols-4">
                 <?php foreach($tas as $brg) : ?>
                <div class="col-6 col-md-3 mb-3">
                    <div class="card">
                        <img src="<?php echo base_url().'/uploads/'.$brg->gambar ?>" class="card-img-top h-100">
                          <div class="card-body">
                            <h5 class="card-title mb-3"><?php echo $brg->nama_brg ?></h5>
                            <small><?php echo $brg->keterang ?></small><br>
                            <span class="badge rounded-pill bg-success mb-3">Rp. <?php echo number_format($brg->harga,0,',','.')  ?></span><br>
                            <?php echo anchor('dashboard/tambah_ke_keranjang/'.$brg->id_brg,'<div class="btn btn-sm btn-primary">Tambah</div>') ?>
                            <?php echo anchor('dashboard/detail/'.$brg->id_brg,'<div class="btn btn-sm btn-success">Detail</div>') ?>
                          </div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
        </div>

</main> 
        

        <!--=============== MAIN JS ===============-->