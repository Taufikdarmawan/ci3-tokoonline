<body>
    <!--========== SCROLL TOP ==========-->
        <a href="#" class="scrolltop" id="scroll-top">
            <i class='bx bx-chevron-up scrolltop__icon'></i>
        </a>

    <!--=============== HEADER ===============-->
        <header class="l-header" id="header">
            <nav class="nav bd-container">
                <a href="#" class="nav__logo">Boostrapt</a>

                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list mt-3">
                        <li class="nav__item">
                            <a href="<?php echo base_url('Welcome/index') ?>" class="nav__link">
                                <i class="fas fa-regular fa-home fa-lg"></i>
                                <span class="nav__name">Home</span>
                            </a>  
                        </li>
                        
                        <li class="nav__item">
                            <a href="#about" class="nav__link">
                                <i class="fas fa-regular fa-search fa-lg"></i>
                                <span class="nav__name">search</span>
                            </a>
                        </li>

                        <li class="nav__item nav__link">
                            <a class="nav__link">
                                <i class="fas fa-regular fa-shopping-cart fa-lg"></i>
                                <span class="nav__name"><?php 
                                $keranjang = 'Keranjang '. $this->cart->total_items();
                                ?>
                        
                                <?php echo anchor('dashboard/detail_keranjang',  $keranjang ) ?></span>
                            </a>
                        </li>

                        <li class="nav__item">
                            <a href="<?php echo base_url('dashboard/Pembayaran') ?>" class="nav__link">
                                <i class="fas fa-book fa-lg"></i>
                                <span class="nav__name">Pesanan</span>
                            </a>
                        </li>

                        <!-- Nav Item - User Information -->
                        <li class="nav__item dropdown no-arrow">
                            <a href="<?php echo base_url('dashboard/user') ?>" class="nav__link" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-regular fa-user-circle fa-lg"></i>
                                <span class="nav__name">akun</span>
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal">
                                <?php echo anchor('auth/logout','<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400 ml-3"></i>Logout') ?>
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>

                
            </nav>
        </header>

   
<div class="container-fluid bg-primary py-5">
                <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <?php if($this->session->userdata('username')) {
                                } ?>
                    <div>selamat datang <?php echo $this->session->userdata('username') ?></div>
                    <?php echo anchor('auth/logout','Logout') ?>
                </div> 
            </div>
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</div>

