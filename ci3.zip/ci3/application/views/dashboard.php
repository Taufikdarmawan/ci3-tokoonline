 <!--========== HOME ==========-->
            <!--=============== HOME ===============-->
            <div class="container-fluid bg-primary py-5">
                <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Shop in style</h1>
                    <p class="lead fw-normal text-white-50 mb-0">With this shop hompeage template</p>
                </div>
            </div>
            </div>
            <!--========== MENU ==========-->
            <section class="menu section bd-container" id="menu">
                <span class="section-subtitle">Special</span>
                <h2 class="section-title">Menu Populer</h2>

                <div class="menu__container bd-grid">
                    <?php foreach($barang as $brg) : ?>
                    <div class="menu__content">
                        <img src="<?php echo base_url().'/uploads/'.$brg->gambar ?>"  class="menu__img">
                        <h3 class="menu__name"><?php echo $brg->nama_brg ?></h3>
                        <span class="menu__detail"><?php echo $brg->keterang ?></span>
                        <span class="menu__preci">Rp. <?php echo number_format($brg->harga,0,',','.')  ?></span>
                        <?php echo anchor('dashboard/tambah_ke_keranjang/'.$brg->id_brg,'<div class="button menu__button"><i class="fas fa-shopping-cart"></i></div>') ?>
                            <?php echo anchor('dashboard/detail/'.$brg->id_brg,'<div class="btn btn-sm btn-primary">Detail</div>') ?>
                        
                    </div>

                   <?php endforeach;?>
                </div>
            </section>