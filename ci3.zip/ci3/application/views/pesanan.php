<div class="container-fluid py-3 mt-5">
	<div class="alert alert-success">
		<p class="text-center align-middle">Selamat, pesanan anda berhasil di proses</p>
	</div>
</div>
