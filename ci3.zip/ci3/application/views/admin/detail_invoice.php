<div class="container-fluid">
	<h4>Detail Pesanan <div class="btn btn-sm btn-success">No. Invoice: <?php echo $catatan->id ?></div></h4>


	<table class="table table-bordered table-hover table-striped" >
		<thead>
		<tr>
			<th>No</th>
			<th>Id Barang</th>
			<th>Nama PRODUK</th>
			<th>Jumlah Pesanan</th>
			<th>Harga Satuan</th>
			<th>TOTAL</th>
		</tr>
		</thead>

		<tbody>
		<?php 
		$no=1;
		$total = 0;
		
		foreach($pelanggan as $pelang):
			$subtotal = $pelang->jumlah * $pelang->harga;
			$total += $subtotal;?>

		 <tr>
		 	<td ><?php echo $no++ ?></td>
		 	<td ><?php echo $pelang->id_brg ?></td>
		 	<td ><?php echo $pelang->nama_brg ?></td>
		 	<td ><?php echo $pelang->jumlah ?></td>
		 	<td ><?php echo number_format($pelang->harga,0,',','.') ?></td>
		 	<td ><?php echo number_format($subtotal,0,',','.') ?></td>
		 </tr>

		 <?php endforeach; ?>

		</tbody>
	</table>
</div>
