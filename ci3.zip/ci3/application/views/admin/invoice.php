<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Invoice</h1>
                    

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>Nama Pemesan</th>
                                            <th>Alamat Pemesan</th>
                                            <th>nomer telpon</th>
                                            <th>Tanggal Pemesan</th>
                                            <th>Batas Pembayaran</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach($catatan as $catat) : ?>
                                        <tr>
                                            <td><?php echo $no++ ?></td>
                                            <td><?php echo $catat->nama  ?></td>
                                            <td><?php echo $catat->alamat ?></td>
                                            <td><?php echo $catat->nomer ?></td>
                                            <td><?php echo $catat->tgl_pesan ?></td>
                                            <td><?php echo $catat->batas_bayar ?></td>

                                             <td>
                                                 <a href="<?php echo base_url('admin/invoice/detail/'.$catat->id) ?>" class="btn btn-primary" ><i class="fas fa-book"></i></a>
                                                 <a href="<?php echo base_url('admin/invoice/edit/'.$catat->id) ?>" class="btn btn-warning" ><i class="fa fa-edit"></i></a>
                                                  <a onclick="deleteConfirm('<?php echo site_url('admin/invoice/hapus/'.$catat->id) ?>')"
                                                    class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                             </td>
                                             
                                        </tr>
                                  
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>

  <!-- Logout Delete Confirmation-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">Apakah Anda Yakin Ingin Menghapus Data Ini?</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a id="btn-delete" class="btn btn-danger" href="#">Hapus</a>
      </div>
    </div>
  </div>
</div>