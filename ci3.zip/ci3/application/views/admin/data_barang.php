<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Data Barang</h1>
                    

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <button  class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_barang"><i class="fas fa-plus fa-sm"></i> Tambah Barang</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NAMA BARANG</th>
                                            <th>KETERANGAN</th>
                                            <th>KATEGORI</th>
                                            <th>HARGA</th>
                                            <th>STOK</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach($barang as $brg) : ?>
                                        <tr>
                                            <td><?php echo $no++ ?></td>
                                            <td><?php echo $brg->nama_brg ?></td>
                                            <td><?php echo $brg->keterang ?></td>
                                            <td><?php echo $brg->Kategori ?></td>
                                            <td><?php echo $brg->harga ?></td>
                                            <td><?php echo $brg->stok ?></td>

                                             <td>
                                                 <a href="<?php echo base_url('admin/data_barang/edit/' .$brg->id_brg) ?>" class="btn btn-warning" ><i class="fa fa-edit"></i></a>
                                                 <a onclick="deleteConfirm('<?php echo site_url('admin/data_barang/hapus/' .$brg->id_brg) ?>')"
                                                    class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                             </td>
                                             
                                        </tr>
                                  
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>

<!-- Modal Tambah-->
<div class="modal fade" id="tambah_barang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Barang</h5>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
       <form action="<?php echo base_url(). 'admin/data_barang/tambah_aksi'; ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Nama Barang</label>
            <input type="text" name="nama_brg" class="form-control">
            <label>Keterangan</label>
            <input type="text" name="keterang" class="form-control">
            <label>Kategori</label>
            <select class="form-control" name="Kategori">
                <option>tas</option>
                <option>buku</option>
            </select>
            <label>Harga</label>
            <input type="text" name="harga" class="form-control">
            <label>Stok</label>
            <input type="text" name="stok" class="form-control">
            <label>Gambar</label>
            <input type="file" name="gambar" class="form-control">
        </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>

      </form>
      
    </div>
  </div>
</div>

<!-- Modal Hapus-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">Apakah Anda Yakin Ingin Menghapus Data Ini?</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a id="btn-delete" class="btn btn-danger" href="#">Hapus</a>
      </div>
    </div>
  </div>
</div> 