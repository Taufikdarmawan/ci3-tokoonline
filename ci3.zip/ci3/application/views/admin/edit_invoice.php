<div class="container-fluid">
	<h3><i class="fas fa-edit"></i>EDIT Invoice</h3>

	<?php foreach($catatan as $catat) : ?>

		<form method="post" action="<?php echo base_url().'admin/invoice/update' ?> ">

			<div class="form-group">
				<label>nama</label>
				<input type="text" name="nama" class="form-control" value="<?php echo $catat->nama ?>">
			</div>

			<div class="form-group">
				<label>alamat</label>
				<input type="text" name="alamat" class="form-control" value="<?php echo $catat->alamat ?>">
			</div>

			<div class="form-group">
				<label>nomer</label>
				<input type="hidden" name="id" class="form-control" value="<?php echo $catat->id ?>">
				<input type="text" name="nomer" class="form-control" value="<?php echo $catat->nomer ?>">
			</div>


			<button type="submit" class="btn btn-success btn-sm">Simpan</button>
			
		</form>

	<?php endforeach; ?>
</div>